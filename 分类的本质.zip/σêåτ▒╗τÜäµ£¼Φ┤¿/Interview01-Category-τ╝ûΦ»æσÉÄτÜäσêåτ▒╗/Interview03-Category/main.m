//
//  main.m
//  Interview03-Category
//
//  Created by MJ Lee on 2018/5/3.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MJPerson+Eat.h"
#import "MJPerson+Test.h"
#import "MJPerson.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        MJPerson *person = [[MJPerson alloc] init];
        [person run];
//        objc_msgSend(person, @selector(run));
        
//        [person test];
//        [person eat];
//        objc_msgSend(person, @selector(eat));
        
//通过分类添加的test和eat对象方法会被添加到MJPerson类对象的对象方法列表里,不会创建新的类对象,只允许存在一个类对象
//同理:通过分类添加的test和eat类方法也会被添加到MJPerson元类对象里面

        //分类在编译的时候会转换成下面的结构体,一个分类对应一个结构体,后面参与编译的分类会先调用,因为后面参与编译的分类被加在了数组的最前面在运行的时候再通过runtime把下面的结构体添加到类对象里面
        //将分类添加到类对象数据里面的过程
        /*
         1.通过Runtime加载某个类的所有Category数据
         2.把所有Category的方法、属性、协议数据，合并到一个大数组中
           (后面参与编译的Category数据，会在数组的前面)
         3.将合并后的分类数据（方法、属性、协议），插入到类原来数据的前面
         */
        
        //因为分类添加到类对象数据的前面了,所以调用方法的时候先分类,后类对象
        
        /*
         struct category_t {
         const char *name;  //类名
         classref_t cls;
         struct method_list_t *instanceMethods;  //对象方法
         struct method_list_t *classMethods;     //类方法
         struct protocol_list_t *protocols;      //协议
         struct property_list_t *instanceProperties; //属性
         // Fields below this point are not always present on disk.
         struct property_list_t *_classProperties;
         
         method_list_t *methodsForMeta(bool isMeta) {
         if (isMeta) return classMethods;
         else return instanceMethods;
         }
         
         property_list_t *propertiesForMeta(bool isMeta, struct header_info *hi);
         };
         */
        
        // 通过runtime动态将分类的方法合并到类对象、元类对象中
    }
    return 0;
}
